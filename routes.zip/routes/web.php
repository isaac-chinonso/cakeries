<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Frontend\PageController@index');

Route::get('/about', 'Frontend\PageController@about');

Route::get('/contact', 'Frontend\PageController@contact');

Route::get('/offer', 'Frontend\PageController@offer');

Route::group([ 'middleware' => 'web', 'prefix' => 'cake', 'before' => 'cake' ], function(){

    Route::get('/allcakes', 'Frontend\PageController@allcake');

    Route::get('/wedding', 'Frontend\PageController@wedding');

    Route::get('/men', 'Frontend\PageController@men');

    Route::get('/specialevent', 'Frontend\PageController@specialevent');

    Route::get('/boy', 'Frontend\PageController@boy');

    Route::get('/cupcake', 'Frontend\PageController@cupcake');

    Route::get('/girl', 'Frontend\PageController@girl');

    Route::get('/lady', 'Frontend\PageController@lady');

});
